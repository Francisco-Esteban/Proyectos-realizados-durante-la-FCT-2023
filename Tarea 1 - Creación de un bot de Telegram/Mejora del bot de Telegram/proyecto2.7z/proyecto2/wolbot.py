
import socket
import re
from telethon import TelegramClient
from telethon import events
from wakeonlan import send_magic_packet


ordenadoresparaboot = { 

    1: {"direccionip" : "123.123.123.123", "mac": "9UG:4HNG:UN3:4N9F:UFUN9"},

    2: {"direccionip" : "123.123.123.123", "mac": "9UG:4HNG:UN3:4N9F:UFUN9"},

    3: {"direccionip" : "123.123.123.123", "mac": "9UG:4HNG:UN3:4N9F:UFUN9"},

    4: {"direccionip" : "123.123.123.123", "mac": "9UG:4HNG:UN3:4N9F:UFUN9"} 
                        
                                                                   
} 

# Se crea un proceso que controla todo el envío del paquete WOL

async def enviarwol(event):

    # el try controla el proceso de enviar el paquete correctamente
    try: 

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(('', 9))
        magic_packet = b'\xFF' * 6 + bytes.fromhex(ordenadoresparaboot["mac"].replace(':' ''))


        # enviando el magic packet a la dirección IP por el puerto 9
        sock.sendto(magic_packet, (ordenadoresparaboot["direccionip"], 9))

        
        

    # el except controla todos los resultados que no tienen que ver con el recurso

    except Exception as e:
        
        

    # el finally controla todas las cosas que se hacen se complete el proceso o no
        
            finally:
        
            sock.close()
      