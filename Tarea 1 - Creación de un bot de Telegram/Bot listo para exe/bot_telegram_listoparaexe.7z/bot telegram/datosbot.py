
import telebot



token = "6783665959:AAFaMFFA6OshH5uy0iBjyBTfudgef8btrhQ"




api_id = '23401401'
api_hash = '8cb49adc638c4bdeac52b8252c126110'
chat_name = '@wolfctbot'