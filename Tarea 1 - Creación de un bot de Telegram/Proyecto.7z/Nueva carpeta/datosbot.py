api_id = '23401401'
api_hash = '8cb49adc638c4bdeac52b8252c126110'
bot_token = '6913320914:AAEmd8XnI25yo4-cxFVMLfI-PTZpVWrCd14'
chat_name = '@WOLPowerswitchBot'